package com.flutterflow.mydream

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
