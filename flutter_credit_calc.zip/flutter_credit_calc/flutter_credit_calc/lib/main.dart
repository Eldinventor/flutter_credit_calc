import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'auth/firebase_user_provider.dart';
import 'package:my_dream/login/login_widget.dart';
import 'package:my_dream/credit_page/credit_page_widget.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Flutter App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: MyDreamHomePage(),
    );
  }
}

class MyDreamHomePage extends StatelessWidget {
  const MyDreamHomePage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<MyDreamFirebaseUser>(
      stream: myDreamFirebaseUser,
      initialData: myDreamFirebaseUser.value,
      builder: (context, snapshot) {
        return snapshot.data.when(
          user: (_) => CreditPageWidget(),
          loggedOut: () => LoginWidget(),
          initial: () => Container(
            color: Colors.white,
            child: const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xff4b39ef)),
              ),
            ),
          ),
        );
      },
    );
  }
}
